/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Workflow } from './types';

export const MOCK_WORKFLOWS: Workflow[] = [
  {
    id: '1',
    name: 'AI-based Loan Approval System',
    domain: 'Finance',
    description: 'Automated credit scoring and loan approval using customer financial history and real-time behavioral data.',
    aiType: 'Agentic System',
    dataSensitivity: 'High',
    decisionImpact: 'High',
    riskLevel: 'CRITICAL',
    riskScore: 92,
    riskExplanation: 'High-impact financial decisions involving sensitive PII and complex agentic reasoning propagate risk across the decision chain.',
    regulatoryMapping: [
      {
        name: 'EU AI Act',
        status: 'Non-compliant',
        controls: ['Transparency', 'Risk Management'],
        missingControls: ['Human Oversight', 'Technical Documentation']
      },
      {
        name: 'MAS FEAT',
        status: 'Partial',
        controls: ['Fairness', 'Ethics'],
        missingControls: ['Accountability', 'Transparency']
      },
      {
        name: 'ISO 42001',
        status: 'Partial',
        controls: ['Policy Framework'],
        missingControls: ['Impact Assessment']
      },
      {
        name: 'AI Verify (IMDA)',
        status: 'Compliant',
        controls: ['Technical Robustness'],
        missingControls: []
      }
    ],
    agentTrace: [
      {
        agent: 'Data Agent',
        action: 'Ingest customer data',
        input: 'Customer ID, Bank Statements',
        output: 'Normalized Financial Profile',
        riskContribution: 15,
        dependencies: []
      },
      {
        agent: 'Model Agent',
        action: 'Compute Credit Score',
        input: 'Normalized Profile',
        output: 'Score: 740 (Confidence: 0.89)',
        riskContribution: 25,
        dependencies: ['Data Agent']
      },
      {
        agent: 'Decision Agent',
        action: 'Approve/Deny Loan',
        input: 'Credit Score, Policy Rules',
        output: 'Approved ($50k)',
        riskContribution: 40,
        dependencies: ['Model Agent']
      },
      {
        agent: 'Monitoring Agent',
        action: 'Drift Detection',
        input: 'Decision Output',
        output: 'No drift detected',
        riskContribution: 5,
        dependencies: ['Decision Agent']
      },
      {
        agent: 'Governance Agent',
        action: 'Policy Enforcement',
        input: 'Full Trace',
        output: 'Alert: High Risk Decision',
        riskContribution: 7,
        dependencies: ['Monitoring Agent']
      }
    ],
    decisionTrace: {
      intent: 'Maximize loan approval accuracy while minimizing default risk.',
      dataUsed: ['Credit History', 'Income', 'Employment Status', 'Social Media Activity (Experimental)'],
      assumptions: ['Past financial behavior predicts future reliability', 'Data sources are up-to-date'],
      logic: 'Weighted sum of credit score (60%), income-to-debt ratio (30%), and behavioral signals (10%).',
      failurePoints: ['Bias against low-income demographics', 'Hallucination in behavioral analysis', 'Data drift in economic conditions']
    },
    autonomyLevel: 'RESTRICTED',
    triggeredRules: [
      'High-risk financial decision',
      'Sensitive personal data usage',
      'Lack of explainability in behavioral signals'
    ],
    recommendations: [
      'Add human-in-the-loop review for all approvals > $25k',
      'Implement SHAP/LIME for model explainability',
      'Enable detailed audit logging for agent communications'
    ],
    createdAt: '2026-04-10T10:00:00Z'
  },
  {
    id: '2',
    name: 'Patient Triage Assistant',
    domain: 'Healthcare',
    description: 'LLM-powered assistant to help nurses prioritize emergency room patients based on symptoms.',
    aiType: 'LLM',
    dataSensitivity: 'High',
    decisionImpact: 'High',
    riskLevel: 'HIGH',
    riskScore: 78,
    riskExplanation: 'Medical triage is a high-stakes environment where LLM hallucinations could lead to delayed care.',
    regulatoryMapping: [
      {
        name: 'EU AI Act',
        status: 'Partial',
        controls: ['Human Oversight'],
        missingControls: ['Accuracy Metrics']
      }
    ],
    agentTrace: [],
    decisionTrace: {
      intent: 'Reduce triage wait times.',
      dataUsed: ['Symptom description', 'Vital signs'],
      assumptions: ['User provides accurate symptoms'],
      logic: 'Keyword matching and semantic analysis of severity.',
      failurePoints: ['Hallucination of medical conditions']
    },
    autonomyLevel: 'LIMITED',
    triggeredRules: ['Medical decision support'],
    recommendations: ['Strict human verification required'],
    createdAt: '2026-04-09T14:30:00Z'
  }
];

export const MOCK_LOGS = [
  { id: 'l1', timestamp: '2026-04-12T08:30:00Z', workflow: 'Loan Approval AI', event: 'Policy Trigger', detail: 'High-risk financial decision detected', status: 'Blocked' },
  { id: 'l2', timestamp: '2026-04-12T08:15:00Z', workflow: 'Patient Triage Assistant', event: 'Human Review', detail: 'Manual override of triage priority', status: 'Approved' },
  { id: 'l3', timestamp: '2026-04-12T07:45:00Z', workflow: 'Loan Approval AI', event: 'Data Drift', detail: 'Shift in income distribution detected', status: 'Alert' },
  { id: 'l4', timestamp: '2026-04-12T07:00:00Z', workflow: 'System', event: 'Policy Update', detail: 'EU AI Act v2.1 controls applied', status: 'System' },
];

export const MOCK_MONITOR_STATS = [
  { time: '08:00', requests: 120, risk: 5 },
  { time: '08:10', requests: 150, risk: 8 },
  { time: '08:20', requests: 180, risk: 12 },
  { time: '08:30', requests: 140, risk: 7 },
  { time: '08:40', requests: 210, risk: 15 },
  { time: '08:50', requests: 190, risk: 10 },
];

export const MOCK_COMPLIANCE_SUMMARY = [
  { framework: 'EU AI Act', compliant: 12, partial: 4, nonCompliant: 2 },
  { framework: 'MAS FEAT', compliant: 15, partial: 2, nonCompliant: 1 },
  { framework: 'ISO 42001', compliant: 8, partial: 8, nonCompliant: 2 },
  { framework: 'AI Verify', compliant: 18, partial: 0, nonCompliant: 0 },
];
